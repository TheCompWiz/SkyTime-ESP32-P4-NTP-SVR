Runtime log files are created automatically if missing.

events.log
ntp.log.
