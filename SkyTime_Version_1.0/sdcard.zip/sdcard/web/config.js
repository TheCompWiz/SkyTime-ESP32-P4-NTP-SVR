const STATUS_API='/api/status';
const IDENTITY_API='/api/config/identity';
const NETWORK_API='/api/config/network';
const REBOOT_API='/api/system/reboot';
const REFRESH_MS=3000;
const $=id=>document.getElementById(id);

function setText(id,value){const el=$(id);if(el)el.textContent=value??'--';}
function setPill(id,text,state){const el=$(id);if(!el)return;el.textContent=text;el.classList.remove('ok','warn','bad');el.classList.add(state);}

function validIdentityText(value,maxLen){
  if(!value || value.length>=maxLen)return false;
  return /^[A-Za-z0-9 ._-]+$/.test(value);
}

function validHostname(value){
  if(!value || value.length>=32)return false;
  return /^[A-Za-z0-9_-]+$/.test(value);
}

function validIp(value){
  const parts=String(value).split('.');
  if(parts.length!==4)return false;
  return parts.every(p=>/^\d+$/.test(p)&&Number(p)>=0&&Number(p)<=255);
}

function updateNetworkInputState(){
  const disabled=$('dhcpEnabled').checked;
  ['staticIp','subnetMask','gateway','dns'].forEach(id=>{
    const el=$(id);
    if(el)el.disabled=disabled;
  });
}

function updateShell(data){
  const eth=data.ethernet||{},sd=data.sd||{},cfg=data.config||{},web=data.web||{},gps=data.gps||{},identity=data.identity||{};

  setPill('systemHealthEth',eth.link?'ETH UP':'ETH DOWN',eth.link?'ok':'bad');
  setPill('systemHealthSd',sd.mounted?'SD MOUNTED':'SD FAIL',sd.mounted?'ok':'bad');
  setPill('systemHealthCfg',cfg.state==='LOADED'?'CFG LOADED':'CFG CHECK',cfg.state==='LOADED'?'ok':'warn');
  setPill('systemHealthWeb',web.state==='RUNNING'?'WEB RUNNING':'WEB CHECK',web.state==='RUNNING'?'ok':'warn');

  setText('identityLine',`${identity.node_id||'SkyTime'} • ${identity.role||'Node'} • ${(identity.site_name||identity.location_name||'')}`);

  if(typeof gps.lat==='number'&&typeof gps.lon==='number'){
    setText('locationTag',`${gps.lat.toFixed(5)}, ${gps.lon.toFixed(5)}`);
  }else{
    setText('locationTag','--.-----, --.-----');
  }

  const conn=$('connectionStatus');
  conn.textContent='Online';
  conn.classList.remove('warn','bad');
  conn.classList.add('ok');

  setText('lastUpdate',`Browser update: ${new Date().toLocaleTimeString()}`);
}

async function getJson(url){
  const response=await fetch(url,{cache:'no-store'});
  if(!response.ok)throw new Error(`HTTP ${response.status}`);
  return await response.json();
}

async function loadIdentity(){
  const data=await getJson(IDENTITY_API);
  if(data.ok===false)throw new Error(data.error||'Unable to load identity');

  $('nodeId').value=data.node_id||'';
  $('role').value=data.role||'Standalone';
  $('siteName').value=data.site_name||'';
}

async function loadNetwork(){
  const data=await getJson(NETWORK_API);
  if(data.ok===false)throw new Error(data.error||'Unable to load network');

  $('hostname').value=data.hostname||'';
  $('dhcpEnabled').checked=!!data.dhcp;
  $('staticIp').value=data.ip||'';
  $('subnetMask').value=data.subnet||'';
  $('gateway').value=data.gateway||'';
  $('dns').value=data.dns||'';
  updateNetworkInputState();
}

async function saveIdentity(){
  const nodeId=$('nodeId').value.trim();
  const role=$('role').value.trim();
  const siteName=$('siteName').value.trim();

  if(!validIdentityText(nodeId,32)){setText('saveStatus','Invalid System value.');return;}
  if(!validIdentityText(role,24)){setText('saveStatus','Invalid Role value.');return;}
  if(!validIdentityText(siteName,40)){setText('saveStatus','Invalid Site Name value.');return;}

  setText('saveStatus','Saving...');

  const response=await fetch(IDENTITY_API,{
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body:JSON.stringify({node_id:nodeId,role:role,site_name:siteName})
  });

  const data=await response.json();

  if(!response.ok || data.ok===false)throw new Error(data.error||'Save failed');

  setText('saveStatus','Identity saved.');
  await refreshShell();
}

async function saveNetwork(){
  const hostname=$('hostname').value.trim();
  const dhcp=$('dhcpEnabled').checked;
  const ip=$('staticIp').value.trim();
  const subnet=$('subnetMask').value.trim();
  const gateway=$('gateway').value.trim();
  const dns=$('dns').value.trim();

  if(!validHostname(hostname)){setText('networkSaveStatus','Invalid Hostname.');return;}

  if(!dhcp){
    if(!validIp(ip)){setText('networkSaveStatus','Invalid Static IP.');return;}
    if(!validIp(subnet)){setText('networkSaveStatus','Invalid Subnet Mask.');return;}
    if(!validIp(gateway)){setText('networkSaveStatus','Invalid Gateway.');return;}
    if(!validIp(dns)){setText('networkSaveStatus','Invalid DNS Server.');return;}
  }

  setText('networkSaveStatus','Saving...');

  const response=await fetch(NETWORK_API,{
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body:JSON.stringify({
      hostname:hostname,
      dhcp:dhcp,
      ip:ip,
      subnet:subnet,
      gateway:gateway,
      dns:dns,
      ntp_enabled:true
    })
  });

  const data=await response.json();

  if(!response.ok || data.ok===false)throw new Error(data.error||'Network save failed');

  setText('networkSaveStatus','Network saved. Reboot required to apply.');setText('rebootStatus','Reboot required to apply network changes.');
  await refreshShell();
}


async function rebootSystem(){
  if(!confirm('Reboot SkyTime now? Network changes will apply after reboot.'))return;

  setText('rebootStatus','Reboot request sent...');

  const response=await fetch(REBOOT_API,{
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body:'{}'
  });

  const data=await response.json();

  if(!response.ok || data.ok===false)throw new Error(data.error||'Reboot request failed');

  setText('rebootStatus','SkyTime is rebooting. Refresh after link returns.');
}


async function refreshShell(){
  updateShell(await getJson(STATUS_API));
}

async function refresh(){
  try{
    await refreshShell();
  }catch(error){
    const conn=$('connectionStatus');
    conn.textContent='Offline';
    conn.classList.remove('ok','warn');
    conn.classList.add('bad');
    setText('lastUpdate',`Last error: ${error.message}`);
  }
}

$('saveIdentity').addEventListener('click',()=>saveIdentity().catch(error=>setText('saveStatus',`Save error: ${error.message}`)));
$('saveNetwork').addEventListener('click',()=>saveNetwork().catch(error=>setText('networkSaveStatus',`Save error: ${error.message}`)));
$('dhcpEnabled').addEventListener('change',updateNetworkInputState);
$('rebootSystem').addEventListener('click',()=>rebootSystem().catch(error=>setText('rebootStatus',`Reboot error: ${error.message}`)));

Promise.all([loadIdentity(),loadNetwork()])
  .then(refresh)
  .catch(error=>{
    setText('saveStatus',`Load error: ${error.message}`);
    setText('networkSaveStatus',`Load error: ${error.message}`);
    refresh();
  });

setInterval(refresh,REFRESH_MS);
