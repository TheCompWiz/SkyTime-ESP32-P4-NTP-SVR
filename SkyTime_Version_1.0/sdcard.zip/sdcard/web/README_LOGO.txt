SkyTime Version 1.0

Expected logo file:
  /web/SkyTimeLogo.png

If the image is missing, the browser will show a broken image icon.
Copy SkyTimeLogo.png to the SD card as:
  /web/SkyTimeLogo.png
