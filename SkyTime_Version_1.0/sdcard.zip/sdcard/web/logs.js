const STATUS_API='/api/status';
const EVENT_API='/api/logs/events';
const NTP_API='/api/logs/ntp';
const REFRESH_MS=5000;
const $=id=>document.getElementById(id);

function setText(id,value){const el=$(id);if(el)el.textContent=value??'--';}
function setPill(id,text,state){const el=$(id);if(!el)return;el.textContent=text;el.classList.remove('ok','warn','bad');el.classList.add(state);}

function esc(s){
  return String(s)
    .replaceAll('&','&amp;')
    .replaceAll('<','&lt;')
    .replaceAll('>','&gt;')
    .replaceAll('"','&quot;')
    .replaceAll("'","&#39;");
}

function lineClass(line){
  const l=String(line).toUpperCase();

  if(l.includes('ERROR')||l.includes('FAIL')){
    return'log-line error';
  }

  if(l.includes('BAD') && !l.includes('BADMODE=0')){
    return'log-line error';
  }

  if(l.includes('HOLDOVER=YES')||l.includes('NOTREADY')||l.includes('REJECT')){
    return'log-line warn';
  }

  if(l.includes('EVENT')||l.includes('BOOT')){
    return'log-line event';
  }

  if(l.includes('NTP')){
    return'log-line ntp';
  }

  return'log-line';
}

function renderLog(targetId,countId,totalId,data){
  const target=$(targetId);
  if(!target)return;

  if(!data||data.ok===false){
    target.textContent=(data&&data.error)?data.error:'Unable to load log';
    setText(countId,'0 lines');
    setText(totalId,'--');
    return;
  }

  const lines=data.lines||[];
  setText(countId,`${lines.length} lines`);
  setText(totalId,data.count!=null?`${data.count} total`:'--');

  if(!lines.length){
    target.textContent=data.message||'No log entries';
    return;
  }

  target.innerHTML=lines.map(line=>`<div class="${lineClass(line)}">${esc(line)}</div>`).join('');
}

function updateShell(data){
  const eth=data.ethernet||{},sd=data.sd||{},cfg=data.config||{},web=data.web||{},gps=data.gps||{},identity=data.identity||{};
  setPill('systemHealthEth',eth.link?'ETH UP':'ETH DOWN',eth.link?'ok':'bad');
  setPill('systemHealthSd',sd.mounted?'SD MOUNTED':'SD FAIL',sd.mounted?'ok':'bad');
  setPill('systemHealthCfg',cfg.state==='LOADED'?'CFG LOADED':'CFG CHECK',cfg.state==='LOADED'?'ok':'warn');
  setPill('systemHealthWeb',web.state==='RUNNING'?'WEB RUNNING':'WEB CHECK',web.state==='RUNNING'?'ok':'warn');
  setText('identityLine',`${identity.node_id||'SkyTime'} • ${identity.role||'Node'} • ${(identity.site_name||identity.location_name||'')}`);
  if(typeof gps.lat==='number'&&typeof gps.lon==='number')setText('locationTag',`${gps.lat.toFixed(5)}, ${gps.lon.toFixed(5)}`);
  else setText('locationTag','--.-----, --.-----');
  const conn=$('connectionStatus');
  conn.textContent='Online';
  conn.classList.remove('warn','bad');
  conn.classList.add('ok');
  setText('lastUpdate',`Browser update: ${new Date().toLocaleTimeString()}`);
}

async function getJson(url){
  const response=await fetch(url,{cache:'no-store'});
  if(!response.ok)throw new Error(`HTTP ${response.status}`);
  return await response.json();
}

async function refresh(){
  try{
    updateShell(await getJson(STATUS_API));
    renderLog('eventLog','eventCount','eventTotal',await getJson(EVENT_API));
    renderLog('ntpLog','ntpCount','ntpTotal',await getJson(NTP_API));
  }catch(error){
    const conn=$('connectionStatus');
    conn.textContent='Offline';
    conn.classList.remove('ok','warn');
    conn.classList.add('bad');
    setText('lastUpdate',`Last error: ${error.message}`);
  }
}

refresh();
setInterval(refresh,REFRESH_MS);
