const STATUS_API='/api/status';
const REFRESH_MS=5000;
const $=id=>document.getElementById(id);

function setText(id,value){const el=$(id);if(el)el.textContent=value??'--';}
function setPill(id,text,state){const el=$(id);if(!el)return;el.textContent=text;el.classList.remove('ok','warn','bad');el.classList.add(state);}

function updateShell(data){
  const eth=data.ethernet||{},sd=data.sd||{},cfg=data.config||{},web=data.web||{},gps=data.gps||{},identity=data.identity||{};
  setPill('systemHealthEth',eth.link?'ETH UP':'ETH DOWN',eth.link?'ok':'bad');
  setPill('systemHealthSd',sd.mounted?'SD MOUNTED':'SD FAIL',sd.mounted?'ok':'bad');
  setPill('systemHealthCfg',cfg.state==='LOADED'?'CFG LOADED':'CFG CHECK',cfg.state==='LOADED'?'ok':'warn');
  setPill('systemHealthWeb',web.state==='RUNNING'?'WEB RUNNING':'WEB CHECK',web.state==='RUNNING'?'ok':'warn');
  setText('identityLine',`${identity.node_id||'SkyTime'} • ${identity.role||'Node'} • ${(identity.site_name||identity.location_name||'')}`);
  if(typeof gps.lat==='number'&&typeof gps.lon==='number')setText('locationTag',`${gps.lat.toFixed(5)}, ${gps.lon.toFixed(5)}`);
  else setText('locationTag','--.-----, --.-----');
  const conn=$('connectionStatus');
  conn.textContent='Online';
  conn.classList.remove('warn','bad');
  conn.classList.add('ok');
  setText('lastUpdate',`Browser update: ${new Date().toLocaleTimeString()}`);
}

async function refresh(){
  try{
    const response=await fetch(STATUS_API,{cache:'no-store'});
    if(!response.ok)throw new Error(`HTTP ${response.status}`);
    updateShell(await response.json());
  }catch(error){
    const conn=$('connectionStatus');
    conn.textContent='Offline';
    conn.classList.remove('ok','warn');
    conn.classList.add('bad');
    setText('lastUpdate',`Last error: ${error.message}`);
  }
}

refresh();
setInterval(refresh,REFRESH_MS);
